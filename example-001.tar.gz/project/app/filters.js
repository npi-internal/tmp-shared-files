//
// For guidance on how to create filters see:
// https://prototype-kit.service.gov.uk/docs/filters
//

const govukPrototypeKit = require('govuk-prototype-kit')
const addFilter = govukPrototypeKit.views.addFilter

// Add your filters here

addFilter("splitLine", (data) => data.join(",<br>"))

const start = Date.now()

console.log('started waiting at', start)

let a = ''

while (Date.now < (start + 1000)) {
  a += 'a'
}

console.log('reached the end of the timer', a)


